package com.jro.email.spring.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

@Component
public class EmailSender {

	private String FROM = "noreply@hostellerscard.com";
	
	@Autowired
	private MailSender sender;
	
	/**
	 * 
	 * @param name
	 * @param email
	 */
	public void sendWelcomeEmail(String name, String email){
		
		String subject = "Congratulations " + name + "!\n\n";
		String body = "You are now a member of Hostellers Card, the best discount card for travellers.\n" + 
						"We are currently working for providing you the best service ever in discounts online platform dedicated for travellers.\n\n" +
						"The best prices with no middleman taxes.\n\n" +
						"We'll send you an e-mail as soon as we generate your digital card as well as your credentials for platform login.\n\n";
		
		send(FROM, email, subject, body);
	}
	
	/**
	 * 
	 * @param toName
	 * @param toEmail
	 * @param position
	 * @param byName
	 * @param byEmail
	 */
	public void sendReferencedEmail(String toName, String toEmail, int position, String byName, String byEmail){
		String subject = "Good news " + toName + ",\n\n";
		String body = "Your friend " + byName + "(" + byEmail + ") just got registered with your reference code!\n" + 
						"Your current position in the card generation queue is now #" + position + ".\n" + 
						"Let's go " + toName + " the more friends you reference the better will be your position!";
		
		send(FROM, toEmail, subject, body);
	}
	
	/**
	 * 
	 * @param from
	 * @param to
	 * @param subject
	 * @param body
	 */
	private void send(String from, String to, String subject, String body){
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom(from);
		mailMessage.setTo(to);
		mailMessage.setSubject(subject);
		mailMessage.setText(body);
		sender.send(mailMessage);
	}
	
}
