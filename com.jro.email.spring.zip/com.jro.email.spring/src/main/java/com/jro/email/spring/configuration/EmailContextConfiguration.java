package com.jro.email.spring.configuration;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
@ComponentScan(basePackages = {"com.jro.email.spring.*"})
public class EmailContextConfiguration {

	@Bean
	public JavaMailSender getMailSender(){
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		Properties props = new Properties();
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.host", "webdomain01.dnscpanel.com");
		props.setProperty("mail.smtp.port", "465");
		props.setProperty("mail.smtp.username", "noreply@hostellerscard.com");
		props.setProperty("mail.smtp.password", "theone2017");
		props.setProperty("mail.smtp.starttls", "true");
		mailSender.setJavaMailProperties(props);
		return mailSender;
	}
	
}
