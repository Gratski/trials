package com.jro.restpower.dev.configuration.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jro.spring.toms.configuration.exception.DuplicatedEntryException;
import com.jro.spring.toms.configuration.exception.MissingArgumentsException;
import com.jro.spring.toms.configuration.exception.ReferencedEntryException;

@RestController
@RequestMapping(path = "/api/v1")
public class RegistrationController {

	@RequestMapping(method = RequestMethod.GET, path = "/user/{id}")
	public String getUser(@PathVariable String id){
		
		if("1".equals(id)){
			throw new DuplicatedEntryException();
		}
		if("2".equals(id)){
			throw new MissingArgumentsException();
		}
		if("3".equals(id)){
			throw new ReferencedEntryException();
		}
		return "Successfuly registered!";
	}
	
}
