package com.jro.spring.toms.configuration.exception;

public class ReferencedEntryException extends RestException{

}
