package com.jro.spring.toms.configuration.exception;

public class MissingArgumentsException extends RestException{

}
