package com.jro.spring.toms.configuration.exception;

public class RestException extends RuntimeException{

}
