package com.jro.spring.toms.configuration.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.jro.spring.toms.configuration.exception.DuplicatedEntryException;
import com.jro.spring.toms.configuration.exception.MissingArgumentsException;
import com.jro.spring.toms.configuration.exception.ReferencedEntryException;

@ControllerAdvice
public class GeneralExceptionHandler {

	/**
	 * Used when there are some arguments missing
	 */
	@ExceptionHandler(MissingArgumentsException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Arguments are missing")
	public void handleMissingArguments(){}
	
	/**
	 * Used when the referenced friend is not a registered friend
	 */
	@ExceptionHandler(ReferencedEntryException.class)
	@ResponseStatus(value = HttpStatus.UNAUTHORIZED, reason = "The used reference is not applicable")
	public void handleUnauthorized(){}

	/**
	 * Used when there is already an primary or unique value already registerd
	 * with the same value
	 */
	@ExceptionHandler(DuplicatedEntryException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT, reason = "There is an equivalent entity registered")
	public void handleDuplicatedEntries(){}
	
}
