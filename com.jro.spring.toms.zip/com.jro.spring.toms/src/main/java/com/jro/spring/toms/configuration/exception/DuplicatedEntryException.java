package com.jro.spring.toms.configuration.exception;

public class DuplicatedEntryException extends RestException{

}
